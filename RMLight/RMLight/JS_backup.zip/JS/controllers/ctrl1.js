﻿var ctrl1 = function ($scope) {
};