﻿app.directive('topnavigation', function () {
      return {
          restrict: 'E',
          scope: {
          },
          templateUrl: 'Partials/ui-elements/t-topnav.html',
          //template: 'Fff',
          replace: false
      };
  });