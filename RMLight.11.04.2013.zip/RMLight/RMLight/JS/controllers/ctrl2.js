﻿var ctrl2 = function ($scope) {
};